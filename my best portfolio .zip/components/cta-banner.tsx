import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { Reveal } from './motion/reveal'

export function CtaBanner() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-24">
      <Reveal>
        <div className="relative overflow-hidden rounded-3xl bg-foreground px-8 py-16 text-center text-background sm:px-16">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -top-24 left-1/2 size-96 -translate-x-1/2 rounded-full bg-brand/50 blur-3xl"
          />
          <h2 className="relative mx-auto max-w-2xl text-3xl font-semibold tracking-tight text-balance sm:text-5xl">
            Ready to build something great together?
          </h2>
          <p className="relative mx-auto mt-4 max-w-xl text-background/70">
            {"Tell me about your project and I'll get back to you within 24 hours with a free quote."}
          </p>
          <div className="relative mt-8 flex flex-wrap justify-center gap-3">
            <Link
              href="/contact"
              className="group inline-flex h-12 items-center gap-2 rounded-full bg-background px-6 text-sm font-medium text-foreground transition-opacity hover:opacity-90"
            >
              Get a free quote
              <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
            </Link>
            <Link
              href="/pricing"
              className="inline-flex h-12 items-center rounded-full border border-background/25 px-6 text-sm font-medium transition-colors hover:bg-background/10"
            >
              See pricing
            </Link>
          </div>
        </div>
      </Reveal>
    </section>
  )
}
