import { Mail, Phone } from 'lucide-react'
import { FaFacebookF, FaFacebookMessenger, FaWhatsapp } from 'react-icons/fa'
import { profile } from '@/lib/portfolio-data'
import { emailUrl, messengerUrl, phoneUrl, whatsappUrl } from '@/lib/contact'

export const contactChannels = [
  {
    label: 'WhatsApp',
    value: profile.phoneDisplay,
    href: whatsappUrl("Hi Naymul! I'd like to discuss a website project."),
    icon: FaWhatsapp,
    color: 'bg-[#25D366] text-white',
    external: true,
  },
  {
    label: 'Messenger',
    value: 'Chat on Messenger',
    href: messengerUrl(),
    icon: FaFacebookMessenger,
    color: 'bg-[#0084FF] text-white',
    external: true,
  },
  {
    label: 'Phone',
    value: profile.phoneDisplay,
    href: phoneUrl,
    icon: Phone,
    color: 'bg-foreground text-background',
    external: false,
  },
  {
    label: 'Email',
    value: profile.email,
    href: emailUrl('Website project inquiry'),
    icon: Mail,
    color: 'bg-brand text-brand-foreground',
    external: false,
  },
  {
    label: 'Facebook',
    value: 'Follow on Facebook',
    href: profile.facebook,
    icon: FaFacebookF,
    color: 'bg-[#1877F2] text-white',
    external: true,
  },
] as const

export function ContactChannelList() {
  return (
    <ul className="grid gap-3">
      {contactChannels.map((c) => (
        <li key={c.label}>
          <a
            href={c.href}
            {...(c.external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
            className="group flex items-center gap-4 rounded-2xl border border-border bg-card p-4 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lg"
          >
            <span
              className={`flex size-12 shrink-0 items-center justify-center rounded-xl transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-6 ${c.color}`}
            >
              <c.icon className="size-5" aria-hidden="true" />
            </span>
            <span className="min-w-0">
              <span className="block text-sm text-muted-foreground">{c.label}</span>
              <span className="block truncate font-medium">{c.value}</span>
            </span>
          </a>
        </li>
      ))}
    </ul>
  )
}

export function SocialIconRow({ className = '' }: { className?: string }) {
  return (
    <ul className={`flex flex-wrap gap-2 ${className}`}>
      {contactChannels.map((c) => (
        <li key={c.label}>
          <a
            href={c.href}
            aria-label={c.label}
            title={c.label}
            {...(c.external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
            className={`flex size-10 items-center justify-center rounded-full transition-transform duration-300 hover:-translate-y-1 hover:scale-110 ${c.color}`}
          >
            <c.icon className="size-4" aria-hidden="true" />
          </a>
        </li>
      ))}
    </ul>
  )
}
