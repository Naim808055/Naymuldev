import { experience } from '@/lib/portfolio-data'
import { Reveal } from './motion/reveal'
import { SectionHeading } from './section-heading'

export function Experience() {
  return (
    <section className="border-t border-border/60">
      <div className="mx-auto max-w-6xl px-6 py-24">
        <SectionHeading eyebrow="Experience" title="Where I've worked" />
        <ol className="relative border-l border-border pl-8">
          {experience.map((item, i) => (
            <li key={item.title} className="relative pb-12 last:pb-0">
              <span
                aria-hidden="true"
                className="absolute -left-[37px] top-1.5 size-2.5 rounded-full bg-brand ring-4 ring-background"
              />
              <Reveal delay={i * 0.08}>
                <p className="font-mono text-xs text-muted-foreground">{item.period}</p>
                <h3 className="mt-2 text-lg font-semibold">
                  {item.title} <span className="font-normal text-muted-foreground">· {item.company}</span>
                </h3>
                <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted-foreground">{item.description}</p>
              </Reveal>
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}
