import { AppWindow, Check, Gauge, LayoutTemplate, Rocket, ShoppingCart, Wrench } from 'lucide-react'
import { services } from '@/lib/portfolio-data'
import { Reveal } from './motion/reveal'

const icons = {
  layout: LayoutTemplate,
  cart: ShoppingCart,
  app: AppWindow,
  rocket: Rocket,
  gauge: Gauge,
  wrench: Wrench,
}

export function ServicesGrid({ limit, showPoints = false }: { limit?: number; showPoints?: boolean }) {
  const list = limit ? services.slice(0, limit) : services
  return (
    <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
      {list.map((service, i) => {
        const Icon = icons[service.icon]
        return (
          <li key={service.title}>
            <Reveal delay={(i % 3) * 0.08} className="h-full">
              <article className="group h-full rounded-2xl border border-border bg-card p-6 transition-all duration-300 hover:-translate-y-1 hover:border-brand/40 hover:shadow-xl hover:shadow-brand/5">
                <div className="flex size-11 items-center justify-center rounded-xl bg-secondary transition-colors group-hover:bg-brand group-hover:text-brand-foreground">
                  <Icon className="size-5" aria-hidden="true" />
                </div>
                <h3 className="mt-5 text-lg font-semibold">{service.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{service.description}</p>
                {showPoints && (
                  <ul className="mt-5 space-y-2 border-t border-border pt-5 text-sm">
                    {service.points.map((p) => (
                      <li key={p} className="flex items-center gap-2">
                        <Check className="size-4 text-brand" aria-hidden="true" />
                        {p}
                      </li>
                    ))}
                  </ul>
                )}
              </article>
            </Reveal>
          </li>
        )
      })}
    </ul>
  )
}
