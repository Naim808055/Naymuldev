'use client'

import { useState } from 'react'
import { AnimatePresence, motion } from 'motion/react'
import { X } from 'lucide-react'
import { FaWhatsapp } from 'react-icons/fa'
import { contactChannels } from './contact-channels'

const quickChannels = contactChannels.filter((c) => c.label !== 'Facebook')

export function FloatingContact() {
  const [open, setOpen] = useState(false)

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col items-end gap-3">
      <AnimatePresence>
        {open && (
          <motion.ul
            id="quick-contact"
            initial="hidden"
            animate="show"
            exit="hidden"
            variants={{ show: { transition: { staggerChildren: 0.05, staggerDirection: -1 } } }}
            className="flex flex-col items-end gap-3"
          >
            {quickChannels.map((c) => (
              <motion.li
                key={c.label}
                variants={{
                  hidden: { opacity: 0, y: 16, scale: 0.8 },
                  show: { opacity: 1, y: 0, scale: 1 },
                }}
              >
                <a
                  href={c.href}
                  {...(c.external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
                  className="group flex items-center gap-3"
                >
                  <span className="rounded-full bg-background px-3 py-1.5 text-sm font-medium shadow-md ring-1 ring-border">
                    {c.label}
                  </span>
                  <span
                    className={`flex size-12 items-center justify-center rounded-full shadow-lg transition-transform group-hover:scale-110 ${c.color}`}
                  >
                    <c.icon className="size-5" aria-hidden="true" />
                  </span>
                </a>
              </motion.li>
            ))}
          </motion.ul>
        )}
      </AnimatePresence>

      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        aria-controls="quick-contact"
        aria-label={open ? 'Close contact options' : 'Open contact options'}
        className={`relative flex size-14 items-center justify-center rounded-full text-white shadow-xl transition-colors ${
          open ? 'bg-foreground' : 'animate-float bg-[#25D366]'
        }`}
      >
        {!open && (
          <span
            aria-hidden="true"
            className="absolute inset-0 animate-ping rounded-full bg-[#25D366] opacity-40 motion-reduce:hidden"
          />
        )}
        <motion.span key={open ? 'x' : 'wa'} initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }}>
          {open ? <X className="size-6" aria-hidden="true" /> : <FaWhatsapp className="size-7" aria-hidden="true" />}
        </motion.span>
      </button>
    </div>
  )
}
