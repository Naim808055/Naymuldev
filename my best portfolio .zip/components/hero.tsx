'use client'

import Image from 'next/image'
import Link from 'next/link'
import { useRef } from 'react'
import { motion, useReducedMotion, useScroll, useTransform } from 'motion/react'
import { ArrowRight, MapPin } from 'lucide-react'
import { profile } from '@/lib/portfolio-data'
import { SocialIconRow } from './contact-channels'

const headline = ['I', 'build', 'websites', 'that', 'grow', 'your', 'business.']

export function Hero() {
  const ref = useRef<HTMLElement>(null)
  const reduce = useReducedMotion()
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] })
  const textY = useTransform(scrollYProgress, [0, 1], [0, reduce ? 0 : 120])
  const imageY = useTransform(scrollYProgress, [0, 1], [0, reduce ? 0 : -60])
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0])

  return (
    <section ref={ref} className="relative overflow-hidden">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-[linear-gradient(to_right,var(--border)_1px,transparent_1px),linear-gradient(to_bottom,var(--border)_1px,transparent_1px)] bg-[size:56px_56px] opacity-50 [mask-image:radial-gradient(ellipse_at_top,black,transparent_70%)]"
      />
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -left-20 top-10 size-72 animate-blob rounded-full bg-brand/20 blur-3xl motion-reduce:animate-none" />
        <div className="absolute -right-10 top-1/3 size-64 animate-blob rounded-full bg-emerald-400/20 blur-3xl [animation-delay:-5s] motion-reduce:animate-none" />
      </div>
      <div className="relative mx-auto grid max-w-6xl items-center gap-12 px-6 py-20 sm:py-28 lg:grid-cols-[1.3fr_1fr]">
        <motion.div style={{ y: textY, opacity }}>
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 rounded-full border border-border bg-background px-3 py-1 text-xs text-muted-foreground"
          >
            <span className="relative flex size-2">
              <span className="absolute inline-flex size-full animate-ping rounded-full bg-emerald-500 opacity-60" />
              <span className="relative inline-flex size-2 rounded-full bg-emerald-500" />
            </span>
            Available for new projects
          </motion.p>

          <h1 className="mt-6 text-5xl font-semibold tracking-tight text-balance sm:text-6xl lg:text-7xl">
            {headline.map((word, i) => (
              <motion.span
                key={i}
                className={`mr-[0.25em] inline-block ${word === 'grow' ? 'text-brand' : ''}`}
                initial={reduce ? false : { opacity: 0, y: 30, filter: 'blur(8px)' }}
                animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                transition={{ duration: 0.6, delay: 0.1 + i * 0.07, ease: [0.22, 1, 0.36, 1] }}
              >
                {word}
              </motion.span>
            ))}
          </h1>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="mt-6 max-w-xl text-lg leading-relaxed text-muted-foreground text-pretty"
          >
            {`Hi, I'm ${profile.name} — a ${profile.role.toLowerCase()}. ${profile.intro}`}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.75 }}
            className="mt-10 flex flex-wrap items-center gap-3"
          >
            <Link
              href="/contact"
              className="group inline-flex h-12 items-center gap-2 rounded-full bg-foreground px-6 text-sm font-medium text-background transition-opacity hover:opacity-90"
            >
              Start a project
              <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
            </Link>
            <Link
              href="/work"
              className="inline-flex h-12 items-center rounded-full border border-border px-6 text-sm font-medium transition-colors hover:bg-secondary"
            >
              View my work
            </Link>
          </motion.div>

          <div className="mt-8">
            <SocialIconRow />
          </div>

          <p className="mt-6 inline-flex items-center gap-1.5 text-sm text-muted-foreground">
            <MapPin className="size-4" aria-hidden="true" />
            {profile.location} · Working worldwide
          </p>
        </motion.div>

        <motion.div
          style={{ y: imageY }}
          initial={{ opacity: 0, scale: 0.94 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
          className="relative mx-auto w-full max-w-sm"
        >
          <div className="relative aspect-[2/3] overflow-hidden rounded-3xl border border-border bg-secondary">
            <Image
              src="/naymul.png"
              alt={`Portrait of ${profile.name}`}
              fill
              priority
              sizes="(min-width: 1024px) 384px, 90vw"
              className="object-cover"
            />
          </div>
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 1, duration: 0.5 }}
            className="absolute -left-4 bottom-8 animate-float rounded-2xl motion-reduce:animate-none border border-border bg-background/95 px-4 py-3 shadow-lg backdrop-blur sm:-left-10"
          >
            <p className="text-2xl font-semibold">50+</p>
            <p className="text-xs text-muted-foreground">Projects delivered</p>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 1.15, duration: 0.5 }}
            className="absolute -right-4 top-8 animate-float-slow rounded-2xl motion-reduce:animate-none border border-border bg-background/95 px-4 py-3 shadow-lg backdrop-blur sm:-right-8"
          >
            <p className="text-2xl font-semibold">4.9/5</p>
            <p className="text-xs text-muted-foreground">Client rating</p>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}
