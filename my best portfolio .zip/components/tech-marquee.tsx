import { techStack } from '@/lib/portfolio-data'

export function TechMarquee() {
  const items = [...techStack, ...techStack]
  return (
    <section aria-label="Technologies I work with" className="border-y border-border/60 bg-secondary/40 py-6">
      <div className="relative overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_10%,black_90%,transparent)]">
        <ul className="flex w-max animate-marquee gap-12 motion-reduce:animate-none">
          {items.map((tech, i) => (
            <li
              key={`${tech}-${i}`}
              aria-hidden={i >= techStack.length}
              className="font-mono text-sm whitespace-nowrap text-muted-foreground"
            >
              {tech}
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
