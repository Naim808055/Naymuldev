'use client'

import { useSearchParams } from 'next/navigation'
import { Mail } from 'lucide-react'
import { FaFacebookMessenger, FaWhatsapp } from 'react-icons/fa'
import { pricing } from '@/lib/portfolio-data'
import { emailUrl, messengerUrl, whatsappUrl, type ContactChannel } from '@/lib/contact'

const fieldClass =
  'mt-2 w-full rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none transition-shadow focus:border-foreground focus:ring-2 focus:ring-ring/40'

const submitButtons = [
  { channel: 'whatsapp', label: 'Send on WhatsApp', icon: FaWhatsapp, className: 'bg-[#25D366] text-white' },
  { channel: 'messenger', label: 'Send on Messenger', icon: FaFacebookMessenger, className: 'bg-[#0084FF] text-white' },
  { channel: 'email', label: 'Send via Email', icon: Mail, className: 'bg-foreground text-background' },
] as const

export function ContactForm() {
  const params = useSearchParams()
  const selectedPlan = params.get('plan') ?? ''

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const submitter = (e.nativeEvent as SubmitEvent).submitter as HTMLButtonElement | null
    const channel = (submitter?.value ?? 'whatsapp') as ContactChannel
    const data = new FormData(e.currentTarget)
    const name = String(data.get('name') ?? '').trim()
    const subject = `New project inquiry from ${name}`
    const message = [
      `Hi Naymul! I'm ${name}.`,
      `Phone/Email: ${data.get('contact')}`,
      `Package: ${data.get('plan') || 'Not sure yet'}`,
      '',
      String(data.get('message') ?? '').trim(),
    ].join('\n')

    if (channel === 'email') {
      window.location.href = emailUrl(subject, message)
      return
    }
    if (channel === 'messenger') navigator.clipboard?.writeText(message).catch(() => {})
    const url = channel === 'messenger' ? messengerUrl(message) : whatsappUrl(message)
    window.open(url, '_blank', 'noopener,noreferrer')
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5 rounded-3xl border border-border bg-card p-6 sm:p-8">
      <div className="grid gap-5 sm:grid-cols-2">
        <label className="block text-sm font-medium">
          Your name
          <input name="name" required autoComplete="name" className={fieldClass} placeholder="John Doe" />
        </label>
        <label className="block text-sm font-medium">
          Phone or email
          <input
            name="contact"
            required
            autoComplete="email"
            className={fieldClass}
            placeholder="+880 1XXX-XXXXXX"
          />
        </label>
      </div>
      <label className="block text-sm font-medium">
        Package
        <select name="plan" defaultValue={selectedPlan} className={fieldClass}>
          <option value="">Not sure yet</option>
          {pricing.map((p) => (
            <option key={p.name} value={p.name}>
              {p.name} — {p.price}
            </option>
          ))}
        </select>
      </label>
      <label className="block text-sm font-medium">
        Project details
        <textarea
          name="message"
          required
          rows={5}
          className={`${fieldClass} resize-none`}
          placeholder="Tell me about your business, goals and timeline..."
        />
      </label>
      <div className="grid gap-3 sm:grid-cols-3">
        {submitButtons.map((b) => (
          <button
            key={b.channel}
            type="submit"
            name="channel"
            value={b.channel}
            className={`group inline-flex h-12 items-center justify-center gap-2 rounded-full px-4 text-sm font-medium transition-all hover:-translate-y-0.5 hover:shadow-lg ${b.className}`}
          >
            <b.icon className="size-4 transition-transform group-hover:scale-110" aria-hidden="true" />
            {b.label}
          </button>
        ))}
      </div>
      <p className="text-center text-xs text-muted-foreground">
        Your message opens directly in the app you choose — no waiting, reply within 24 hours.
      </p>
    </form>
  )
}
