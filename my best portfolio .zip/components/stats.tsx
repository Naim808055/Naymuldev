import { stats } from '@/lib/portfolio-data'
import { Counter } from './motion/counter'
import { Reveal } from './motion/reveal'

export function Stats() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-20">
      <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-border bg-border lg:grid-cols-4">
        {stats.map((stat, i) => (
          <Reveal key={stat.label} delay={i * 0.08} className="bg-background p-8">
            <dt className="text-sm text-muted-foreground">{stat.label}</dt>
            <dd className="mt-2 text-4xl font-semibold tracking-tight sm:text-5xl">
              <Counter value={stat.value} suffix={stat.suffix} />
            </dd>
          </Reveal>
        ))}
      </dl>
    </section>
  )
}
