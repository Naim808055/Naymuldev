import { process } from '@/lib/portfolio-data'
import { Reveal } from './motion/reveal'

export function ProcessSteps() {
  return (
    <ol className="grid gap-px overflow-hidden rounded-2xl border border-border bg-border sm:grid-cols-2 lg:grid-cols-4">
      {process.map((p, i) => (
        <li key={p.step} className="bg-background">
          <Reveal delay={i * 0.1} className="h-full p-6">
            <span className="font-mono text-sm text-brand">{p.step}</span>
            <h3 className="mt-6 text-lg font-semibold">{p.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{p.description}</p>
          </Reveal>
        </li>
      ))}
    </ol>
  )
}
