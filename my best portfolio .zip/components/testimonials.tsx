import { Star } from 'lucide-react'
import { testimonials } from '@/lib/portfolio-data'
import { SectionHeading } from './section-heading'

type Testimonial = (typeof testimonials)[number]

function TestimonialCard({ t }: { t: Testimonial }) {
  const initials = t.name
    .split(' ')
    .map((n) => n[0])
    .join('')
  return (
    <figure className="w-80 shrink-0 rounded-2xl border border-border bg-card p-6 sm:w-96">
      <div className="flex gap-0.5 text-amber-500" aria-label="5 out of 5 stars">
        {Array.from({ length: 5 }).map((_, i) => (
          <Star key={i} className="size-4 fill-current" aria-hidden="true" />
        ))}
      </div>
      <blockquote className="mt-4 text-sm leading-relaxed text-pretty">{`“${t.quote}”`}</blockquote>
      <figcaption className="mt-6 flex items-center gap-3">
        <span className="flex size-10 items-center justify-center rounded-full bg-brand/10 text-sm font-semibold text-brand">
          {initials}
        </span>
        <span>
          <span className="block text-sm font-medium">{t.name}</span>
          <span className="block text-xs text-muted-foreground">{t.role}</span>
        </span>
      </figcaption>
    </figure>
  )
}

function Row({ items, reverse }: { items: Testimonial[]; reverse?: boolean }) {
  const doubled = [...items, ...items]
  return (
    <div className="group overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_8%,black_92%,transparent)]">
      <div
        className={`flex w-max gap-5 [--marquee-duration:50s] group-hover:[animation-play-state:paused] motion-reduce:animate-none ${reverse ? 'animate-marquee-reverse' : 'animate-marquee'}`}
      >
        {doubled.map((t, i) => (
          <div key={`${t.name}-${i}`} aria-hidden={i >= items.length}>
            <TestimonialCard t={t} />
          </div>
        ))}
      </div>
    </div>
  )
}

export function Testimonials() {
  const half = Math.ceil(testimonials.length / 2)
  return (
    <section className="border-t border-border/60 bg-secondary/40 py-24">
      <div className="mx-auto max-w-6xl px-6">
        <SectionHeading
          align="center"
          eyebrow="Testimonials"
          title="What my clients say"
          description="Trusted by founders, agencies and businesses around the world."
        />
      </div>
      <div className="flex flex-col gap-5">
        <Row items={testimonials.slice(0, half)} />
        <Row items={testimonials.slice(half)} reverse />
      </div>
    </section>
  )
}
