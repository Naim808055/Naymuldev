import Link from 'next/link'
import { navLinks, profile } from '@/lib/portfolio-data'
import { SocialIconRow } from './contact-channels'

export function SiteFooter() {
  return (
    <footer className="border-t border-border/60">
      <div className="mx-auto grid max-w-6xl gap-10 px-6 py-14 md:grid-cols-3">
        <div>
          <Link href="/" className="font-mono text-sm font-semibold">
            {profile.name.toLowerCase()}
            <span className="text-brand">.dev</span>
          </Link>
          <p className="mt-3 max-w-xs text-sm leading-relaxed text-muted-foreground">
            Professional website design & development for businesses that want to grow online.
          </p>
        </div>
        <nav aria-label="Footer">
          <h2 className="text-sm font-medium">Pages</h2>
          <ul className="mt-3 grid grid-cols-2 gap-2 text-sm text-muted-foreground">
            {navLinks.map((link) => (
              <li key={link.href}>
                <Link href={link.href} className="transition-colors hover:text-foreground">
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        <div>
          <h2 className="text-sm font-medium">Get in touch</h2>
          <address className="mt-3 space-y-1.5 text-sm not-italic text-muted-foreground">
            <a href={`tel:${profile.phone}`} className="block transition-colors hover:text-foreground">
              {profile.phoneDisplay}
            </a>
            <a href={`mailto:${profile.email}`} className="block transition-colors hover:text-foreground">
              {profile.email}
            </a>
          </address>
          <SocialIconRow className="mt-4" />
        </div>
      </div>
      <div className="border-t border-border/60">
        <p className="mx-auto max-w-6xl px-6 py-6 text-xs text-muted-foreground">
          {'© '}
          {new Date().getFullYear()} {profile.name}. All rights reserved.
        </p>
      </div>
    </footer>
  )
}
