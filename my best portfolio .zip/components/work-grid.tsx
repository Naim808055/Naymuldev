'use client'

import Image from 'next/image'
import { useState } from 'react'
import { AnimatePresence, motion } from 'motion/react'
import { ArrowUpRight } from 'lucide-react'
import { projects } from '@/lib/portfolio-data'
import { cn } from '@/lib/utils'

const categories = ['All', ...Array.from(new Set(projects.map((p) => p.category)))]

export function WorkGrid({ limit, filterable = false }: { limit?: number; filterable?: boolean }) {
  const [active, setActive] = useState('All')
  const filtered = projects.filter((p) => active === 'All' || p.category === active)
  const list = limit ? filtered.slice(0, limit) : filtered

  return (
    <div>
      {filterable && (
        <div role="group" aria-label="Filter projects" className="mb-10 flex flex-wrap gap-2">
          {categories.map((c) => (
            <button
              key={c}
              type="button"
              aria-pressed={active === c}
              onClick={() => setActive(c)}
              className={cn(
                'rounded-full border px-4 py-1.5 text-sm transition-colors',
                active === c
                  ? 'border-foreground bg-foreground text-background'
                  : 'border-border text-muted-foreground hover:text-foreground',
              )}
            >
              {c}
            </button>
          ))}
        </div>
      )}

      <motion.ul layout className="grid gap-8 md:grid-cols-2">
        <AnimatePresence mode="popLayout">
          {list.map((project, i) => (
            <motion.li
              key={project.title}
              layout
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.5, delay: (i % 2) * 0.1 }}
            >
              <a href={project.href} className="group block">
                <div className="relative aspect-[16/10] overflow-hidden rounded-2xl border border-border bg-secondary">
                  <Image
                    src={project.image || '/placeholder.svg'}
                    alt={`${project.title} project screenshot`}
                    fill
                    sizes="(min-width: 768px) 50vw, 100vw"
                    className="object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <span className="absolute left-4 top-4 rounded-full bg-background/90 px-3 py-1 text-xs font-medium backdrop-blur">
                    {project.category}
                  </span>
                </div>
                <div className="mt-5 flex items-start justify-between gap-4">
                  <div>
                    <h3 className="text-xl font-semibold">{project.title}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{project.description}</p>
                    <ul className="mt-4 flex flex-wrap gap-2">
                      {project.tags.map((tag) => (
                        <li key={tag} className="rounded-full bg-secondary px-2.5 py-1 font-mono text-xs">
                          {tag}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <span className="flex size-10 shrink-0 items-center justify-center rounded-full border border-border transition-all group-hover:rotate-45 group-hover:border-foreground group-hover:bg-foreground group-hover:text-background">
                    <ArrowUpRight className="size-4" aria-hidden="true" />
                    <span className="sr-only">View {project.title}</span>
                  </span>
                </div>
              </a>
            </motion.li>
          ))}
        </AnimatePresence>
      </motion.ul>
    </div>
  )
}
