import Image from 'next/image'
import { profile, skills } from '@/lib/portfolio-data'
import { Reveal } from './motion/reveal'

export function About() {
  return (
    <section className="mx-auto grid max-w-6xl gap-12 px-6 py-24 lg:grid-cols-[1fr_1.4fr]">
      <Reveal>
        <div className="relative mx-auto aspect-[2/3] w-full max-w-sm overflow-hidden rounded-3xl border border-border bg-secondary">
          <Image
            src="/naymul.png"
            alt={`Portrait of ${profile.name}`}
            fill
            sizes="(min-width: 1024px) 40vw, 100vw"
            className="object-cover"
          />
        </div>
      </Reveal>
      <div>
        <Reveal>
          <h2 className="text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
            Developer by trade, problem-solver by nature.
          </h2>
        </Reveal>
        <Reveal delay={0.1}>
          <div className="mt-6 space-y-4 leading-relaxed text-muted-foreground">
            <p>
              {`I'm ${profile.name}, a ${profile.role.toLowerCase()} based in ${profile.location}. For over four years I've helped startups, agencies and local businesses turn ideas into fast, beautiful and reliable websites.`}
            </p>
            <p>
              I care about the details — clean code, smooth interactions, accessibility and performance — because
              those are what make visitors trust a brand and turn into customers.
            </p>
          </div>
        </Reveal>
        <div className="mt-10 grid gap-6 sm:grid-cols-3">
          {skills.map((group, i) => (
            <Reveal key={group.group} delay={0.15 + i * 0.08}>
              <h3 className="font-mono text-xs uppercase tracking-widest text-brand">{group.group}</h3>
              <ul className="mt-3 space-y-1.5 text-sm">
                {group.items.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
