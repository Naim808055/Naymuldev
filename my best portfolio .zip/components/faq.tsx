import { Plus } from 'lucide-react'
import { faqs } from '@/lib/portfolio-data'
import { Reveal } from './motion/reveal'

export function Faq() {
  return (
    <div className="divide-y divide-border border-y border-border">
      {faqs.map((f, i) => (
        <Reveal key={f.question} delay={i * 0.05}>
          <details className="group py-5">
            <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-medium [&::-webkit-details-marker]:hidden">
              {f.question}
              <Plus className="size-5 shrink-0 transition-transform duration-300 group-open:rotate-45" aria-hidden="true" />
            </summary>
            <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted-foreground">{f.answer}</p>
          </details>
        </Reveal>
      ))}
    </div>
  )
}
