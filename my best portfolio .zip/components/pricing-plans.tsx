import { Check, Mail } from 'lucide-react'
import { FaFacebookMessenger, FaWhatsapp } from 'react-icons/fa'
import { pricing } from '@/lib/portfolio-data'
import { emailUrl, messengerUrl, planMessage, whatsappUrl } from '@/lib/contact'
import { cn } from '@/lib/utils'
import { Reveal } from './motion/reveal'

export function PricingPlans() {
  return (
    <ul className="grid items-stretch gap-6 lg:grid-cols-3">
      {pricing.map((plan, i) => (
        <li key={plan.name}>
          <Reveal delay={i * 0.1} className="h-full">
            <article
              className={cn(
                'relative flex h-full flex-col rounded-3xl border p-8 transition-all duration-300 hover:-translate-y-1',
                plan.featured
                  ? 'border-foreground bg-foreground text-background shadow-2xl shadow-brand/20'
                  : 'border-border bg-card hover:shadow-xl',
              )}
            >
              {plan.featured && (
                <span className="absolute -top-3 left-8 rounded-full bg-brand px-3 py-1 text-xs font-medium text-brand-foreground">
                  Most popular
                </span>
              )}
              <h3 className="text-lg font-semibold">{plan.name}</h3>
              <p className={cn('mt-2 text-sm', plan.featured ? 'text-background/70' : 'text-muted-foreground')}>
                {plan.description}
              </p>
              <p className="mt-6 flex items-baseline gap-2">
                <span className="text-5xl font-semibold tracking-tight">{plan.price}</span>
                <span className={cn('text-sm', plan.featured ? 'text-background/60' : 'text-muted-foreground')}>
                  {plan.period}
                </span>
              </p>
              <ul className="mt-8 flex-1 space-y-3 text-sm">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-3">
                    <Check
                      className={cn('mt-0.5 size-4 shrink-0', plan.featured ? 'text-background' : 'text-brand')}
                      aria-hidden="true"
                    />
                    {f}
                  </li>
                ))}
              </ul>
              <a
                href={whatsappUrl(planMessage(plan.name, plan.price))}
                target="_blank"
                rel="noopener noreferrer"
                className="group mt-8 inline-flex h-12 items-center justify-center gap-2 rounded-full bg-[#25D366] text-sm font-medium text-white transition-all hover:-translate-y-0.5 hover:shadow-lg"
              >
                <FaWhatsapp className="size-4 transition-transform group-hover:scale-110" aria-hidden="true" />
                {plan.cta} on WhatsApp
              </a>
              <div className="mt-3 grid grid-cols-2 gap-2">
                <a
                  href={messengerUrl(planMessage(plan.name, plan.price))}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={cn(
                    'inline-flex h-10 items-center justify-center gap-2 rounded-full border text-xs font-medium transition-colors',
                    plan.featured
                      ? 'border-background/25 hover:bg-background/10'
                      : 'border-border hover:bg-secondary',
                  )}
                >
                  <FaFacebookMessenger className="size-3.5 text-[#0084FF]" aria-hidden="true" />
                  Messenger
                </a>
                <a
                  href={emailUrl(`${plan.name} package inquiry`, planMessage(plan.name, plan.price))}
                  className={cn(
                    'inline-flex h-10 items-center justify-center gap-2 rounded-full border text-xs font-medium transition-colors',
                    plan.featured
                      ? 'border-background/25 hover:bg-background/10'
                      : 'border-border hover:bg-secondary',
                  )}
                >
                  <Mail className="size-3.5" aria-hidden="true" />
                  Email
                </a>
              </div>
            </article>
          </Reveal>
        </li>
      ))}
    </ul>
  )
}
