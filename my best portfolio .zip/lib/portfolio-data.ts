export const profile = {
  name: 'Naymul',
  role: 'Full-Stack Developer',
  location: 'Dhaka, Bangladesh',
  email: 'naymul270@gmail.com',
  phone: '+8801715740004',
  phoneDisplay: '+880 1715-740004',
  whatsapp: '8801715740004',
  facebookId: '61594039691981',
  facebook: 'https://www.facebook.com/profile.php?id=61594039691981',
  intro:
    'I design and build fast, accessible and conversion-focused websites and web apps for startups, agencies and growing businesses.',
}

export const navLinks = [
  { label: 'Home', href: '/' },
  { label: 'About', href: '/about' },
  { label: 'Services', href: '/services' },
  { label: 'Work', href: '/work' },
  { label: 'Pricing', href: '/pricing' },
  { label: 'Contact', href: '/contact' },
]

export const techStack = [
  'Next.js',
  'React',
  'TypeScript',
  'Tailwind CSS',
  'Node.js',
  'PostgreSQL',
  'Prisma',
  'Stripe',
  'Vercel',
  'Figma',
  'GraphQL',
  'Docker',
]

export const stats = [
  { value: 50, suffix: '+', label: 'Projects delivered' },
  { value: 30, suffix: '+', label: 'Happy clients' },
  { value: 4, suffix: ' yrs', label: 'Experience' },
  { value: 98, suffix: '%', label: 'Client satisfaction' },
]

export const skills = [
  { group: 'Frontend', items: ['React', 'Next.js', 'TypeScript', 'Tailwind CSS'] },
  { group: 'Backend', items: ['Node.js', 'PostgreSQL', 'REST & GraphQL', 'Prisma'] },
  { group: 'Tools', items: ['Git', 'Vercel', 'Docker', 'Figma'] },
]

export const services = [
  {
    icon: 'layout',
    title: 'Website Design & Development',
    description:
      'Custom, responsive websites built from scratch — fast, SEO-friendly and easy to manage.',
    points: ['Custom UI design', 'Fully responsive', 'SEO optimized'],
  },
  {
    icon: 'cart',
    title: 'E-commerce Solutions',
    description:
      'Online stores with secure checkout, product management and payment gateway integration.',
    points: ['Stripe / SSLCommerz', 'Inventory dashboard', 'Order management'],
  },
  {
    icon: 'app',
    title: 'Web Applications',
    description:
      'Scalable SaaS products, dashboards and internal tools with authentication and databases.',
    points: ['Auth & user roles', 'Database design', 'API integrations'],
  },
  {
    icon: 'rocket',
    title: 'Landing Pages',
    description:
      'High-converting landing pages for product launches, campaigns and lead generation.',
    points: ['Conversion focused', 'Animations', 'Analytics setup'],
  },
  {
    icon: 'gauge',
    title: 'Performance & SEO',
    description:
      'Audit and optimize existing sites for Core Web Vitals, speed and search rankings.',
    points: ['Speed optimization', 'Technical SEO', 'Accessibility fixes'],
  },
  {
    icon: 'wrench',
    title: 'Maintenance & Support',
    description:
      'Ongoing updates, bug fixes, backups and feature additions so your site stays healthy.',
    points: ['Monthly updates', 'Security patches', 'Priority support'],
  },
] as const

export const process = [
  {
    step: '01',
    title: 'Discovery',
    description: 'We discuss your goals, audience and requirements to define a clear project scope.',
  },
  {
    step: '02',
    title: 'Design',
    description: 'I create wireframes and a polished visual design for your review and feedback.',
  },
  {
    step: '03',
    title: 'Development',
    description: 'Your site is built with modern, clean code and tested across every device.',
  },
  {
    step: '04',
    title: 'Launch & Support',
    description: 'We go live, and I stay available for updates, fixes and future improvements.',
  },
]

export const projects = [
  {
    title: 'ShopFlow',
    category: 'E-commerce',
    description:
      'A headless e-commerce storefront with cart, checkout and an admin dashboard for managing inventory.',
    tags: ['Next.js', 'Stripe', 'PostgreSQL'],
    image: '/projects/shopflow.png',
    href: '#',
  },
  {
    title: 'TaskBoard',
    category: 'Web App',
    description:
      'Real-time collaborative kanban board with drag-and-drop, team workspaces and activity history.',
    tags: ['React', 'Node.js', 'WebSockets'],
    image: '/projects/taskboard.png',
    href: '#',
  },
  {
    title: 'WeatherNow',
    category: 'Web App',
    description:
      'A clean weather app with 7-day forecasts, location search and beautiful data visualizations.',
    tags: ['TypeScript', 'Charts', 'API'],
    image: '/projects/weathernow.png',
    href: '#',
  },
  {
    title: 'Lumen Studio',
    category: 'Website',
    description:
      'A portfolio website for a creative studio with smooth page transitions and a headless CMS.',
    tags: ['Next.js', 'CMS', 'Motion'],
    image: '/projects/lumen.png',
    href: '#',
  },
  {
    title: 'FitTrack',
    category: 'Landing Page',
    description:
      'A high-converting launch page for a fitness app that grew the waitlist to 5,000+ sign-ups.',
    tags: ['Landing', 'Analytics', 'A/B Testing'],
    image: '/projects/fittrack.png',
    href: '#',
  },
  {
    title: 'Ledgerly',
    category: 'Web App',
    description:
      'An invoicing and expense dashboard for freelancers with reports, exports and team access.',
    tags: ['SaaS', 'PostgreSQL', 'Auth'],
    image: '/projects/ledgerly.png',
    href: '#',
  },
]

export const experience = [
  {
    period: '2024 — Present',
    title: 'Full-Stack Developer',
    company: 'Freelance',
    description: 'Designing and shipping web apps for startups and small businesses, end to end.',
  },
  {
    period: '2022 — 2024',
    title: 'Frontend Developer',
    company: 'Tech Studio',
    description:
      'Built reusable component libraries and improved page performance across client products.',
  },
  {
    period: '2021 — 2022',
    title: 'Junior Web Developer',
    company: 'Digital Agency',
    description: 'Developed responsive marketing sites and landing pages with modern tooling.',
  },
]

export const testimonials = [
  {
    quote:
      'Naymul delivered our e-commerce store ahead of schedule. Sales went up 40% in the first month thanks to the faster checkout.',
    name: 'Rafiq Ahmed',
    role: 'Founder, UrbanThreads',
  },
  {
    quote:
      'Clear communication, beautiful design and rock-solid code. He understood exactly what our startup needed.',
    name: 'Sarah Mitchell',
    role: 'CEO, Brightlane',
  },
  {
    quote:
      'Our old site was slow and outdated. Naymul rebuilt it and our Google ranking and leads improved within weeks.',
    name: 'Tanvir Hasan',
    role: 'Director, Hasan Consulting',
  },
  {
    quote:
      'The dashboard he built saves our team hours every week. Truly a professional to work with.',
    name: 'Emily Chen',
    role: 'Product Lead, Ledgerly',
  },
  {
    quote:
      'Incredible attention to detail and smooth animations. Our landing page now converts like never before.',
    name: 'Nusrat Jahan',
    role: 'Marketing Manager, FitTrack',
  },
  {
    quote:
      'Fast, reliable and always available for support after launch. Highly recommended for any web project.',
    name: 'David Okafor',
    role: 'Owner, Lumen Studio',
  },
]

export const pricing = [
  {
    name: 'Starter',
    price: '$299',
    period: 'one-time',
    description: 'Perfect for personal brands and small businesses getting online.',
    features: [
      'Up to 5 pages',
      'Responsive design',
      'Contact form',
      'Basic SEO setup',
      '1 round of revisions',
      '2 weeks free support',
    ],
    cta: 'Get started',
    featured: false,
  },
  {
    name: 'Business',
    price: '$799',
    period: 'one-time',
    description: 'For growing businesses that need a professional, custom website.',
    features: [
      'Up to 12 pages',
      'Custom UI/UX design',
      'Animations & interactions',
      'CMS / blog integration',
      'Advanced SEO & analytics',
      '3 rounds of revisions',
      '1 month free support',
    ],
    cta: 'Choose Business',
    featured: true,
  },
  {
    name: 'Premium',
    price: '$1,999+',
    period: 'per project',
    description: 'Full-featured web apps and e-commerce stores built to scale.',
    features: [
      'Unlimited pages',
      'E-commerce or web app',
      'Payment gateway integration',
      'Auth & admin dashboard',
      'Database & API development',
      'Unlimited revisions',
      '3 months priority support',
    ],
    cta: 'Let\u2019s talk',
    featured: false,
  },
]

export const faqs = [
  {
    question: 'How long does it take to build a website?',
    answer:
      'A Starter website usually takes 1–2 weeks, Business websites 2–4 weeks and Premium projects 4–8 weeks depending on scope.',
  },
  {
    question: 'Do you offer payment in installments?',
    answer:
      'Yes. Typically 50% upfront to start the project and 50% after final approval, before launch.',
  },
  {
    question: 'Will my website work on mobile devices?',
    answer:
      'Absolutely. Every website I build is fully responsive and tested on phones, tablets and desktops.',
  },
  {
    question: 'Can I update the content myself?',
    answer:
      'Yes. With the Business and Premium plans I can integrate a CMS so you can edit text, images and blog posts without code.',
  },
  {
    question: 'Do you provide hosting and domain?',
    answer:
      'I help you set up hosting (e.g. Vercel) and connect your domain. Domain purchase costs are paid separately.',
  },
]
