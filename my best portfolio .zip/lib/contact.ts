import { profile } from './portfolio-data'

export type ContactChannel = 'whatsapp' | 'messenger' | 'email' | 'phone'

export function whatsappUrl(message?: string) {
  const base = `https://wa.me/${profile.whatsapp}`
  return message ? `${base}?text=${encodeURIComponent(message)}` : base
}

export function messengerUrl(message?: string) {
  const base = `https://m.me/${profile.facebookId}`
  return message ? `${base}?text=${encodeURIComponent(message)}` : base
}

export function emailUrl(subject?: string, body?: string) {
  const params = new URLSearchParams()
  if (subject) params.set('subject', subject)
  if (body) params.set('body', body)
  const query = params.toString().replace(/\+/g, '%20')
  return `mailto:${profile.email}${query ? `?${query}` : ''}`
}

export const phoneUrl = `tel:${profile.phone}`

export function planMessage(planName: string, price: string) {
  return `Hi Naymul! I'm interested in the ${planName} package (${price}). Can we discuss my website project?`
}
