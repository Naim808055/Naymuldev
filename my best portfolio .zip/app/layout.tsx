import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Inter, JetBrains_Mono } from 'next/font/google'
import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import { ScrollProgress } from '@/components/motion/scroll-progress'
import { FloatingContact } from '@/components/floating-contact'
import { profile } from '@/lib/portfolio-data'
import './globals.css'

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' })
const mono = JetBrains_Mono({ subsets: ['latin'], variable: '--font-mono-jb' })

const siteUrl = process.env.VERCEL_PROJECT_PRODUCTION_URL
  ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}`
  : 'http://localhost:3000'

const description =
  'Naymul is a full-stack web developer in Dhaka, Bangladesh offering professional website design, e-commerce and web app development with transparent pricing. Contact on WhatsApp, Messenger or email.'

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: 'Naymul — Website Design & Development in Bangladesh',
    template: '%s — Naymul',
  },
  description,
  keywords: [
    'web developer Bangladesh',
    'website design Dhaka',
    'Next.js developer',
    'e-commerce website',
    'portfolio website',
    'freelance web developer',
    'Naymul',
  ],
  authors: [{ name: profile.name }],
  creator: profile.name,
  alternates: { canonical: '/' },
  openGraph: {
    type: 'website',
    url: '/',
    siteName: 'Naymul.dev',
    title: 'Naymul — Website Design & Development',
    description,
    images: [{ url: '/naymul.png', alt: 'Naymul, full-stack web developer' }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Naymul — Website Design & Development',
    description,
    images: ['/naymul.png'],
  },
  robots: { index: true, follow: true },
  generator: 'v0.app',
  icons: {
    icon: [
      { url: '/icon-light-32x32.png', media: '(prefers-color-scheme: light)' },
      { url: '/icon-dark-32x32.png', media: '(prefers-color-scheme: dark)' },
      { url: '/icon.svg', type: 'image/svg+xml' },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  colorScheme: 'light',
  themeColor: '#ffffff',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${mono.variable} light bg-background scroll-smooth`}>
      <body className="font-sans antialiased">
        <ScrollProgress />
        <SiteHeader />
        <main>{children}</main>
        <SiteFooter />
        <FloatingContact />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              '@context': 'https://schema.org',
              '@type': 'ProfessionalService',
              name: 'Naymul — Website Design & Development',
              url: siteUrl,
              image: `${siteUrl}/naymul.png`,
              description,
              telephone: profile.phone,
              email: profile.email,
              address: { '@type': 'PostalAddress', addressLocality: 'Dhaka', addressCountry: 'BD' },
              founder: { '@type': 'Person', name: profile.name, jobTitle: profile.role },
              sameAs: [profile.facebook, `https://wa.me/${profile.whatsapp}`],
            }),
          }}
        />
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
