import type { MetadataRoute } from 'next'
import { navLinks } from '@/lib/portfolio-data'

export const siteUrl = process.env.VERCEL_PROJECT_PRODUCTION_URL
  ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}`
  : 'http://localhost:3000'

export default function sitemap(): MetadataRoute.Sitemap {
  return navLinks.map((link) => ({
    url: `${siteUrl}${link.href === '/' ? '' : link.href}`,
    lastModified: new Date(),
    changeFrequency: 'monthly',
    priority: link.href === '/' ? 1 : 0.8,
  }))
}
