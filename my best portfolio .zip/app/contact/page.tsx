import type { Metadata } from 'next'
import { Suspense } from 'react'
import { Clock, MapPin } from 'lucide-react'
import { PageHero } from '@/components/page-hero'
import { ContactForm } from '@/components/contact-form'
import { ContactChannelList } from '@/components/contact-channels'
import { Reveal } from '@/components/motion/reveal'
import { profile } from '@/lib/portfolio-data'

export const metadata: Metadata = {
  title: 'Contact',
  description: `Contact ${profile.name} on WhatsApp, Messenger, phone (${profile.phoneDisplay}) or email for a free website quote.`,
  alternates: { canonical: '/contact' },
}

const details = [
  { icon: MapPin, label: 'Location', value: profile.location },
  { icon: Clock, label: 'Response time', value: 'Replies within 24 hours' },
]

export default function ContactPage() {
  return (
    <>
      <PageHero
        eyebrow="Contact"
        title="Let's start your project."
        description="Share a few details about what you need and I'll reply with a free quote and next steps."
      />
      <section className="mx-auto grid max-w-6xl gap-12 px-6 py-24 lg:grid-cols-[1fr_1.5fr]">
        <Reveal className="space-y-8">
          <ContactChannelList />
          <ul className="flex flex-wrap gap-x-6 gap-y-3 text-sm text-muted-foreground">
            {details.map((d) => (
              <li key={d.label} className="inline-flex items-center gap-2">
                <d.icon className="size-4" aria-hidden="true" />
                {d.value}
              </li>
            ))}
          </ul>
        </Reveal>
        <Reveal delay={0.1}>
          <Suspense fallback={<div className="h-[520px] rounded-3xl border border-border bg-card" />}>
            <ContactForm />
          </Suspense>
        </Reveal>
      </section>
    </>
  )
}
