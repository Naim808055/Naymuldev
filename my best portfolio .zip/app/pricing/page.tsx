import type { Metadata } from 'next'
import { PageHero } from '@/components/page-hero'
import { PricingPlans } from '@/components/pricing-plans'
import { SectionHeading } from '@/components/section-heading'
import { Faq } from '@/components/faq'
import { CtaBanner } from '@/components/cta-banner'

export const metadata: Metadata = {
  title: 'Pricing',
  description: 'Transparent website development pricing — Starter, Business and Premium packages.',
}

export default function PricingPage() {
  return (
    <>
      <PageHero
        eyebrow="Pricing"
        title="Website packages for every budget."
        description="Transparent, fixed pricing with no hidden fees. Need something custom? Get in touch for a tailored quote."
      />
      <section className="mx-auto max-w-6xl px-6 py-24">
        <PricingPlans />
        <p className="mt-10 text-center text-sm text-muted-foreground">
          All prices in USD. 50% upfront, 50% on completion. Custom requirements are quoted separately.
        </p>
      </section>
      <section className="mx-auto max-w-3xl px-6 pb-24">
        <SectionHeading align="center" eyebrow="FAQ" title="Frequently asked questions" />
        <Faq />
      </section>
      <CtaBanner />
    </>
  )
}
