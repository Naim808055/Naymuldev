import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { Hero } from '@/components/hero'
import { TechMarquee } from '@/components/tech-marquee'
import { SectionHeading } from '@/components/section-heading'
import { ServicesGrid } from '@/components/services-grid'
import { Stats } from '@/components/stats'
import { WorkGrid } from '@/components/work-grid'
import { ProcessSteps } from '@/components/process-steps'
import { Testimonials } from '@/components/testimonials'
import { PricingPlans } from '@/components/pricing-plans'
import { CtaBanner } from '@/components/cta-banner'

function MoreLink({ href, label }: { href: string; label: string }) {
  return (
    <Link href={href} className="group mt-10 inline-flex items-center gap-2 text-sm font-medium">
      {label}
      <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
    </Link>
  )
}

export default function HomePage() {
  return (
    <>
      <Hero />
      <TechMarquee />

      <section className="mx-auto max-w-6xl px-6 py-24">
        <SectionHeading
          eyebrow="Services"
          title="Everything you need to launch and grow online"
          description="From a simple business website to a full e-commerce platform — designed, built and supported end to end."
        />
        <ServicesGrid limit={3} />
        <MoreLink href="/services" label="Explore all services" />
      </section>

      <Stats />

      <section className="mx-auto max-w-6xl px-6 py-24">
        <SectionHeading
          eyebrow="Selected work"
          title="Recent projects"
          description="A few products I've designed and developed for clients."
        />
        <WorkGrid limit={4} />
        <MoreLink href="/work" label="View all projects" />
      </section>

      <section className="mx-auto max-w-6xl px-6 pb-24">
        <SectionHeading eyebrow="Process" title="How we'll work together" />
        <ProcessSteps />
      </section>

      <Testimonials />

      <section className="mx-auto max-w-6xl px-6 py-24">
        <SectionHeading
          align="center"
          eyebrow="Pricing"
          title="Simple, transparent pricing"
          description="Choose a package that fits your needs. Every plan includes responsive design and clean code."
        />
        <PricingPlans />
      </section>

      <CtaBanner />
    </>
  )
}
