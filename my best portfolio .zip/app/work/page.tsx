import type { Metadata } from 'next'
import { PageHero } from '@/components/page-hero'
import { WorkGrid } from '@/components/work-grid'
import { CtaBanner } from '@/components/cta-banner'

export const metadata: Metadata = {
  title: 'Work',
  description: 'Selected websites, e-commerce stores and web apps built by Naymul.',
}

export default function WorkPage() {
  return (
    <>
      <PageHero
        eyebrow="Portfolio"
        title="Selected work & case studies."
        description="A collection of websites, online stores and web applications I've designed and built for clients."
      />
      <section className="mx-auto max-w-6xl px-6 py-24">
        <WorkGrid filterable />
      </section>
      <CtaBanner />
    </>
  )
}
