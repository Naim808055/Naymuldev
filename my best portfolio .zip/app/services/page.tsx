import type { Metadata } from 'next'
import { PageHero } from '@/components/page-hero'
import { SectionHeading } from '@/components/section-heading'
import { ServicesGrid } from '@/components/services-grid'
import { ProcessSteps } from '@/components/process-steps'
import { Testimonials } from '@/components/testimonials'
import { CtaBanner } from '@/components/cta-banner'

export const metadata: Metadata = {
  title: 'Services',
  description: 'Website design, e-commerce, web app development, SEO and maintenance services by Naymul.',
}

export default function ServicesPage() {
  return (
    <>
      <PageHero
        eyebrow="Services"
        title="Web development services built for results."
        description="Whether you need a new website, an online store or a custom web app, I handle everything from design to launch."
      />
      <section className="mx-auto max-w-6xl px-6 py-24">
        <ServicesGrid showPoints />
      </section>
      <section className="mx-auto max-w-6xl px-6 pb-24">
        <SectionHeading
          eyebrow="Process"
          title="A clear, proven workflow"
          description="You'll always know what's happening and what comes next."
        />
        <ProcessSteps />
      </section>
      <Testimonials />
      <CtaBanner />
    </>
  )
}
