import type { Metadata } from 'next'
import { PageHero } from '@/components/page-hero'
import { About } from '@/components/about'
import { Stats } from '@/components/stats'
import { Experience } from '@/components/experience'
import { CtaBanner } from '@/components/cta-banner'

export const metadata: Metadata = {
  title: 'About',
  description: 'Learn more about Naymul, a full-stack developer building websites and web apps for businesses.',
}

export default function AboutPage() {
  return (
    <>
      <PageHero
        eyebrow="About me"
        title="Helping businesses grow with great websites."
        description="A little about who I am, what I do and the experience I bring to every project."
      />
      <About />
      <Stats />
      <Experience />
      <CtaBanner />
    </>
  )
}
